#include <stdio.h>
    
void square(int w);

void spiral(int w);

void rotation(int w);